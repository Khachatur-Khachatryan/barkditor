# W9-Dark

GTK theme based on B00merang-Project Windows 8.1 theme that based on the Windows 8.1 appearance.

Taskbar edited for Cinnamon only. It was Linux Mint.

Project in development. This is Beta version.

![W9-Dark](https://raw.githubusercontent.com/md2222/W9-Dark/main/W9-Dark-example-01.png)

### Manual installation

Extract W9-Dark folder to the themes directory i.e. '/home/USERNAME/.themes'. You can rename the folder. This will be the name of the theme.
